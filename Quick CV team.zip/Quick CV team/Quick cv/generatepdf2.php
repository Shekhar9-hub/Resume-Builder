
<?php
session_start();
$id = $_GET['id'];
include('dbconn.php');
$sql = "select * from personal_details where id = $id";
$result1 = $con->query($sql);
$row = $result1->fetch_array();
$sq = "select * from education_details where eid = $id";
$result2 = $con->query($sq);
$row2 = $result2->fetch_array();
$name = $row['name'];
$course = $row2['deg'];
$resume = "Creative Resume ".$id.".pdf";
$q = "insert into student_resume(sid,name,course,resume) values($id,'$name','$course','$resume')";
$con->query($q);  
if(($row2['pname']=="NA" || $row2['pdeg']=="NA" || $row2['pdate']=="NA") && ($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA"))
                            {
$html = "<!DOCTYPE html>
<html>
<head>
<title>Creative Resume</title>
<style>

  body{
    font-family:sans-serif;
    margin:0px;
  }
  h1{

font-weight:light;
margin:0px;
font-size:30px;
  }
.text-center{
    text-align:center;
    font-size:50px;
}
.w3-text-teal{
    color:teal;
}
.w3-teal{
    background-color:crimson;
    color:white;


  
}
.container-fluid{
margin-top:20px;
}
.row{

margin-bottom:50px;

}
.col-sm-4{
    width:50%;
    height:auto;
    float:left;
    margin-left:20px;
   
}

.col-sm-8{
    width:50%;
    height:auto;
    float:left;
}
.progress{
    width:100%;
    background-color:lightgrey;
    height:25px;
    border-radius:4px;
}
.progress-bar{
    height:25px;
    background-color:crimson;
    color:white;
    padding:0px 5px;
}
.left{
    padding-left:10px;
    padding-right:50px;
    padding-top:30px;
    padding-bottom:30px;

}
.right{
    padding-right:220px;
}
</style>
</head>
<body>

<h1>". $row['name']."</h1>
<p>".$row['address']."<br>".$row['email']."<br>".$row['phone']."</p>
<h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> PROFESSIONAL SUMMARY</h1>   

<br>
<span style='font-size:15px'>
<br><b>".$row2['summary']."</b>
<br>
<br></span>

<h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>SKILLS</h1>
<br><b>".$row2['skill']."<b>
                 <div class='progress'>
                     <div class='progress-bar bg-danger' style='width:50%'>
                     <b>".$row2['level']."<b> 50%
                     </div>
                 </div>
                 <br>
                <br>
                <b>".$row2['skill2']."<b>
                 <div class='progress'>
                    <div class='progress-bar bg-danger' style='width:50%'>
                    <b>".$row2['level2']."<b> 50%
                    </div>
                </div>
                <br>
                <br>
                <b>".$row2['skill3']."<b>
                <div class='progress'>
                    <div class='progress-bar bg-danger' style='width:75%'>
                    <b>".$row2['level3']."<b> 75%
                    </div>
                </div>
               
<br>
<br>
<br>

<h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> EMPLOYEMENT HISTORY</h1>   

<br>
<h1 class>".$row['job']."</h1><br>
<span class='w3-text-red'>
<b>Starting Date</b> ".$row['sdate']."
<br>
<b> Ending Date </b> ".$row['edate']."</span><br>

<span>". $row['desp']."</span>
<br>
<br>

<h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>HOBBIES</h1>
<br><b>".$row2['h1']."<b>
                 
                 <br>
                <br>
                <b>".$row2['h2']."<b>
                <br>
                
              
<br>
<br>
<br>

<h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> EDUCATION</h1>   

<br>
<p class='pt-5'>
                    <b>Graduation Year</b>
                    <br>
                    
                    <span class='w3-text-red'>".$row2['grad']."</span><br>
                    <b class='w3-large'>College Name</b><br>
                                <span class='font-weight-bold'>". $row2['college']."</span><br>
                                <span class='small'><b>Course: </b>". $row2['deg']."</span><br>
                                <span class='small'><b>Marks: </b>". $row2['gmark']."</span><br>
                                <span class='small'><b>Marks: </b>". $row2['city']."</span><br>
                                <span class='small'><b>Marks: </b>". $row2['state']."</span>
                                
                   <br>
                   <br>
                   <b class='w3-large'>School Name</b><br>
                                <span class='font-weight-bold'>".$row2['school']."</span><br>
                                <span class='small'><b>Year of Higher Studies: </b>". $row2['high']."</span><br>
                                <span class='small'><b>Marks: </b>".$row2['marks']."</span><br>
                                <span class='small'><b>City: </b>".$row2['sc']."</span><br>
                                <span class='small'><b>State: </b>".$row2['ss']."</span>
                    </p>

<h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>Lanuguages</h1>
<h1 class='bg-danger w3-text-white p-2'>LANGUAGES</h1>
                 <br>
                 <br>
                 ENGLISH
                 <div class='progress'>
                    <div class='progress-bar bg-danger' style='width:60%'>
                       60%
                    </div>
                </div>
                <br>
               <br>
               PUNJABI
                <div class='progress'>
                   <div class='progress-bar bg-danger' style='width:50%'>
                      50%
                   </div>
               </div>
               <br>
               <br>
               HINDI
               <div class='progress'>
                   <div class='progress-bar bg-danger' style='width:40%'>
                      40%
                   </div>
               </div>
               <br>
               <br>
               <h1 class='bg-danger w3-text-white p-2'>HONORS</h1>
               <p>
                 
                   <b>Board Member mensa, NY</b><br>
                 <span class='w3-text-red'>".date('d/m/Y')."</span>
               </p>
              
<br>
<br>
<br>

       
       
        
</body>
</html>";
}
else if($row2['oname']=="NA" || 
$row2['odeg']=="NA" || $row2['odate']=="NA")
{
    $html = "<!DOCTYPE html>
    <html>
    <head>
    <title>Creative Resume</title>
    <style>
    
      body{
        font-family:sans-serif;
        margin:0px;
      }
      h1{
    
    font-weight:light;
    margin:0px;
    font-size:30px;
      }
    .text-center{
        text-align:center;
        font-size:50px;
    }
    .w3-text-teal{
        color:teal;
    }
    .w3-teal{
        background-color:crimson;
        color:white;
    
    
      
    }
    .container-fluid{
    margin-top:20px;
    }
    .row{
    
    margin-bottom:50px;
    
    }
    .col-sm-4{
        width:50%;
        height:auto;
        float:left;
        margin-left:20px;
       
    }
    
    .col-sm-8{
        width:50%;
        height:auto;
        float:left;
    }
    .progress{
        width:100%;
        background-color:lightgrey;
        height:25px;
        border-radius:4px;
    }
    .progress-bar{
        height:25px;
        background-color:crimson;
        color:white;
        padding:0px 5px;
    }
    .left{
        padding-left:10px;
        padding-right:50px;
        padding-top:30px;
        padding-bottom:30px;
    
    }
    .right{
        padding-right:220px;
    }
    </style>
    </head>
    <body>
    
    <h1>". $row['name']."</h1>
    <p>".$row['address']."<br>".$row['email']."<br>".$row['phone']."</p>
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> PROFESSIONAL SUMMARY</h1>   
    
    <br>
    <span style='font-size:15px'>
    <br><b>".$row2['summary']."</b>
    <br>
    <br></span>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>SKILLS</h1>
    <br><b>".$row2['skill']."<b>
                     <div class='progress'>
                         <div class='progress-bar bg-danger' style='width:50%'>
                         <b>".$row2['level']."<b> 50%
                         </div>
                     </div>
                     <br>
                    <br>
                    <b>".$row2['skill2']."<b>
                     <div class='progress'>
                        <div class='progress-bar bg-danger' style='width:50%'>
                        <b>".$row2['level2']."<b> 50%
                        </div>
                    </div>
                    <br>
                    <br>
                    <b>".$row2['skill3']."<b>
                    <div class='progress'>
                        <div class='progress-bar bg-danger' style='width:75%'>
                        <b>".$row2['level3']."<b> 75%
                        </div>
                    </div>
                   
    <br>
    <br>
    <br>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> EMPLOYEMENT HISTORY</h1>   
    
    <br>
    <h1 class>".$row['job']."</h1><br>
    <span class='w3-text-red'>
    <b>Starting Date</b> ".$row['sdate']."
    <br>
    <b> Ending Date </b> ".$row['edate']."</span><br>
    
    <span>". $row['desp']."</span>
    <br>
    <br>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>HOBBIES</h1>
    <br><b>".$row2['h1']."<b>
                     
                     <br>
                    <br>
                    <b>".$row2['h2']."<b>
                    <br>
                    
                  
    <br>
    <br>
    <br>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> EDUCATION</h1>   
    
    <br>
    <p class='pt-5'>
                        <b>Graduation Year</b>
                        <br>
                        
                        <span class='w3-text-red'>".$row2['grad']."</span><br>
                        <b class='w3-large'>College Name</b><br>
                                    <span class='font-weight-bold'>". $row2['college']."</span><br>
                                    <span class='small'><b>Course: </b>". $row2['deg']."</span><br>
                                    <span class='small'><b>Marks: </b>". $row2['gmark']."</span><br>
                                    <span class='small'><b>City: </b>". $row2['city']."</span><br>
                                    <span class='small'><b>State: </b>". $row2['state']."</span>
                                    
                       <br>
                       <br>
                       <b>Post Graduation Year</b>
                       <br>
                       
                       <span class='w3-text-red'>".$row2['pdate']."</span><br>
                       <b class='w3-large'>College Name</b><br>
                                   <span class='font-weight-bold'>". $row2['pname']."</span><br>
                                   <span class='small'><b>Course: </b>". $row2['pdeg']."</span><br>
                                   <span class='small'><b>Marks: </b>". $row2['pmark']."</span><br>
                                  
                                   
                      <br>
                      <br>
                      
                       <b class='w3-large'>School Name</b><br>
                                    <span class='font-weight-bold'>".$row2['school']."</span><br>
                                    <span class='small'><b>Year of Higher Studies: </b>". $row2['high']."</span><br>
                                    <span class='small'><b>Marks: </b>".$row2['marks']."</span><br>
                                    <span class='small'><b>City: </b>".$row2['sc']."</span><br>
                                    <span class='small'><b>State: </b>".$row2['ss']."</span>
                        </p>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>Lanuguages</h1>
    <h1 class='bg-danger w3-text-white p-2'>LANGUAGES</h1>
                     <br>
                     <br>
                     ENGLISH
                     <div class='progress'>
                        <div class='progress-bar bg-danger' style='width:60%'>
                           60%
                        </div>
                    </div>
                    <br>
                   <br>
                   PUNJABI
                    <div class='progress'>
                       <div class='progress-bar bg-danger' style='width:50%'>
                          50%
                       </div>
                   </div>
                   <br>
                   <br>
                   HINDI
                   <div class='progress'>
                       <div class='progress-bar bg-danger' style='width:40%'>
                          40%
                       </div>
                   </div>
                   <br>
                   <br>
                   <h1 class='bg-danger w3-text-white p-2'>HONORS</h1>
                   <p>
                     
                       <b>Board Member mensa, NY</b><br>
                     <span class='w3-text-red'>".date('d/m/Y')."</span>
                   </p>
                  
    <br>
    <br>
    <br>
    
           
           
            
    </body>
    </html>";
}
else
{
    $html = "<!DOCTYPE html>
    <html>
    <head>
    <title>Creative Resume</title>
    <style>
    
      body{
        font-family:sans-serif;
        margin:0px;
      }
      h1{
    
    font-weight:light;
    margin:0px;
    font-size:30px;
      }
    .text-center{
        text-align:center;
        font-size:50px;
    }
    .w3-text-teal{
        color:teal;
    }
    .w3-teal{
        background-color:crimson;
        color:white;
    
    
      
    }
    .container-fluid{
    margin-top:20px;
    }
    .row{
    
    margin-bottom:50px;
    
    }
    .col-sm-4{
        width:50%;
        height:auto;
        float:left;
        margin-left:20px;
       
    }
    
    .col-sm-8{
        width:50%;
        height:auto;
        float:left;
    }
    .progress{
        width:100%;
        background-color:lightgrey;
        height:25px;
        border-radius:4px;
    }
    .progress-bar{
        height:25px;
        background-color:crimson;
        color:white;
        padding:0px 5px;
    }
    .left{
        padding-left:10px;
        padding-right:50px;
        padding-top:30px;
        padding-bottom:30px;
    
    }
    .right{
        padding-right:220px;
    }
    </style>
    </head>
    <body>
    
    <h1>". $row['name']."</h1>
    <p>".$row['address']."<br>".$row['email']."<br>".$row['phone']."</p>
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> PROFESSIONAL SUMMARY</h1>   
    
    <br>
    <span style='font-size:15px'>
    <br><b>".$row2['summary']."</b>
    <br>
    <br></span>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>SKILLS</h1>
    <br><b>".$row2['skill']."<b>
                     <div class='progress'>
                         <div class='progress-bar bg-danger' style='width:50%'>
                         <b>".$row2['level']."<b> 50%
                         </div>
                     </div>
                     <br>
                    <br>
                    <b>".$row2['skill2']."<b>
                     <div class='progress'>
                        <div class='progress-bar bg-danger' style='width:50%'>
                        <b>".$row2['level2']."<b> 50%
                        </div>
                    </div>
                    <br>
                    <br>
                    <b>".$row2['skill3']."<b>
                    <div class='progress'>
                        <div class='progress-bar bg-danger' style='width:75%'>
                        <b>".$row2['level3']."<b> 75%
                        </div>
                    </div>
                   
    <br>
    <br>
    <br>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> EMPLOYEMENT HISTORY</h1>   
    
    <br>
    <h1 class>".$row['job']."</h1><br>
    <span class='w3-text-red'>
    <b>Starting Date</b> ".$row['sdate']."
    <br>
    <b> Ending Date </b> ".$row['edate']."</span><br>
    
    <span>". $row['desp']."</span>
    <br>
    <br>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>HOBBIES</h1>
    <br><b>".$row2['h1']."<b>
                     
                     <br>
                    <br>
                    <b>".$row2['h2']."<b>
                    <br>
                    
                  
    <br>
    <br>
    <br>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 ' style='font-size:25px'> EDUCATION</h1>   
    
    <br>
    <p class='pt-5'>
                        <b>Graduation Year</b>
                        <br>
                        
                        <span class='w3-text-red'>".$row2['grad']."</span><br>
                        <b class='w3-large'>College Name</b><br>
                                    <span class='font-weight-bold'>". $row2['college']."</span><br>
                                    <span class='small'><b>Course: </b>". $row2['deg']."</span><br>
                                    <span class='small'><b>Marks: </b>". $row2['gmark']."</span><br>
                                    <span class='small'><b>City: </b>". $row2['city']."</span><br>
                                    <span class='small'><b>State: </b>". $row2['state']."</span>
                                    
                       <br>
                       <br>
                       <b>Post Graduation Year</b>
                       <br>
                       
                       <span class='w3-text-red'>".$row2['pdate']."</span><br>
                       <b class='w3-large'>College Name</b><br>
                                   <span class='font-weight-bold'>". $row2['pname']."</span><br>
                                   <span class='small'><b>Course: </b>". $row2['pdeg']."</span><br>
                                   <span class='small'><b>Marks: </b>". $row2['pmark']."</span><br>
                                  
                                   
                      <br>
                      <br>
                      <b>Other Education or Diploma Year</b>
                       <br>
                       
                       <span class='w3-text-red'>".$row2['odate']."</span><br>
                       <b class='w3-large'>College Name</b><br>
                                   <span class='font-weight-bold'>". $row2['oname']."</span><br>
                                   <span class='small'><b>Course: </b>". $row2['odeg']."</span><br>
                                   <span class='small'><b>Marks: </b>". $row2['omark']."</span><br>
                                  
                                   
                      <br>
                      <br>
                       <b class='w3-large'>School Name</b><br>
                                    <span class='font-weight-bold'>".$row2['school']."</span><br>
                                    <span class='small'><b>Year of Higher Studies: </b>". $row2['high']."</span><br>
                                    <span class='small'><b>Marks: </b>".$row2['marks']."</span><br>
                                    <span class='small'><b>City: </b>".$row2['sc']."</span><br>
                                    <span class='small'><b>State: </b>".$row2['ss']."</span>
                        </p>
    
    <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2 right' style='font-size:25px'>Lanuguages</h1>
    <h1 class='bg-danger w3-text-white p-2'>LANGUAGES</h1>
                     <br>
                     <br>
                     ENGLISH
                     <div class='progress'>
                        <div class='progress-bar bg-danger' style='width:60%'>
                           60%
                        </div>
                    </div>
                    <br>
                   <br>
                   PUNJABI
                    <div class='progress'>
                       <div class='progress-bar bg-danger' style='width:50%'>
                          50%
                       </div>
                   </div>
                   <br>
                   <br>
                   HINDI
                   <div class='progress'>
                       <div class='progress-bar bg-danger' style='width:40%'>
                          40%
                       </div>
                   </div>
                   <br>
                   <br>
                   <h1 class='bg-danger w3-text-white p-2'>HONORS</h1>
                   <p>
                     
                       <b>Board Member mensa, NY</b><br>
                     <span class='w3-text-red'>".date('d/m/Y')."</span>
                   </p>
                  
    <br>
    <br>
    <br>
    
           
           
            
    </body>
    </html>";

}
// <div class='container-fluid'>
//        <div class='row'>
//        <div class='col-sm-8'>
//        <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2' style='font-size:23px'> PROFESSIONAL SUMMARY</h1>
//         <p class='mt-5 text-justify'>
//            ".$row2['summary']."
//         </p>
//         </div>
        
//         <div class='col-sm-4'>
//        <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2'> SKILLS</h1>
//                 <br>
//                  <br>
//                  <b>".$row2['skill']."<b>
//                  <div class='progress'>
//                      <div class='progress-bar bg-danger' style='width:50%'>
//                      <b>".$row2['level']."<b> 50%
//                      </div>
//                  </div>
//                  <br>
//                 <br>
//                 <b>".$row2['skill2']."<b>
//                  <div class='progress'>
//                     <div class='progress-bar bg-danger' style='width:50%'>
//                     <b>".$row2['level2']."<b> 50%
//                     </div>
//                 </div>
//                 <br>
//                 <br>
//                 <b>".$row2['skill3']."<b>
//                 <div class='progress'>
//                     <div class='progress-bar bg-danger' style='width:75%'>
//                     <b>".$row2['level3']."<b> 75%
//                     </div>
//                 </div>
//                 </div>
//                 <br>
            
//                 </div>
//             </div>

//             <br>
//             <br>
            
           
?>
<?php

// Include autoloader 
require_once 'dompdf/autoload.inc.php'; 
 
// Reference the Dompdf namespace 
use Dompdf\Dompdf; 
 
// Instantiate and use the dompdf class 
$dompdf = new Dompdf();


$dompdf->loadHtml($html);

 
// (Optional) Setup the paper size and orientation 
$dompdf->setPaper('A4', 'Portrait'); 
 
// Render the HTML as PDF 
$dompdf->render(); 
//$dompdf->set_base_path('../css/bootstrap.min.css');
// Output the generated PDF (1 = download and 0 = preview) 
if(isset($_SESSION['admin']))
{
$dompdf->stream("Creative Resume", array("Attachment" => 1));
}
else
{
    $dompdf->stream("Creative Resume", array("Attachment" => 0));
    $output = $dompdf->output();
    file_put_contents("student resume/Creative Resume ".$id.".pdf", $output);
}
?>
