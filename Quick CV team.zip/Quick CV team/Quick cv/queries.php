<?php
session_start();
if(!isset($_SESSION['admin']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('adminnav.php');
    ?>
<div class="container-fluid" style='width:50%;padding-top:100px'>
  <div class="row">
    <div class="col-sm-4">
    <!-- <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
     -->
    </div>
    <div class="col-sm-8 text-center">
        <h1 class='text-center'>View All Queries
           </h1>
            <br>
            <table class="table table-bordered table-striped table-hover">
		<tr><th>Sr.No.</th><th>Name</th><th>Email</th><th>Comments</th><th>Date Time</th>
			<th>Delete</th></tr>
		<?php
		include("dbconn.php");
		$query = "select * from contact";
		$result = $con->query($query);
		$cnt=1;
		while(list($a,$b,$c,$d,$e) = $result->fetch_array())
		{
			echo "<tr><td>$cnt</td><td>$b</td><td>$c</td><td>$d</td><td>$e</td><td><a href='querie.php?id=$a'>Delete</td></tr>";
        $cnt++;
        }
			?>
		</table>
            </div>
            </div>
            </div>
    <?php
    if(isset($_GET['id']))
    {
        $id = $_GET['id'];
        include('dbconn.php');
        $sql = "delete from queries where id = $id";
        if($con->query($sql))
        {
            echo "<script>alert('Query is deleted successfully');
            location.replace('contact.php');</script>";
        }
        else{
            echo "<script>alert('Query is not deleted');
            location.replace('contact.php');</script>";
        }
    }
}
?>