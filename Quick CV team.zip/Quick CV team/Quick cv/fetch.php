<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "resume");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM signup
  WHERE name LIKE '%".$search."%'";
//   OR Address LIKE '%".$search."%' 
//   OR City LIKE '%".$search."%' 
//   OR PostalCode LIKE '%".$search."%' 
//   OR Country LIKE '%".$search."%'
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
  $cnt = 1;
 $output .= '
  <div class="table-responsive">
   <table class="table table-bordered">
    <tr>
     <th>ID</th>
     <th>Name</th>
     <th>Email</th>
    
     
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>

    <td>'.$cnt.'</td>
    <td>'.$row["name"].'</td>
    <td>'.$row["email"].'</td>
    
    
   </tr>
  ';
  $cnt++;
 }
 echo $output;
}




else
{
 echo 'Data Not Found';
}
}
// else
// {
//  $query = "
//   select * from signup;
//  ";
// }
// // $result = mysqli_query($connect, $query);
// if(mysqli_num_rows($result) > 0)
// {
//   $cnt = 1;
//  $output .= '
//   <div class="table-responsive">
//    <table class="table table-bordered">
//     <tr>
//      <th>ID</th>
//      <th>Name</th>
//      <th>Email</th>
    
     
//     </tr>
//  ';
//  while($row = mysqli_fetch_array($result))
//  {
//   $output .= '
//    <tr>

//     <td>'.$cnt.'</td>
//     <td>'.$row["name"].'</td>
//     <td>'.$row["email"].'</td>
    
    
//    </tr>
//   ';
//   $cnt++;
//  }
//  echo $output;
// }
// else
// {
//  echo 'Data Not Found';
// }

?>