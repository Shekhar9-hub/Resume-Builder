<?php
 $id = $_GET['eid'];
 include('dbconn.php');
 $sql = "select * from personal_details where id = $id";
 $result1 = $con->query($sql);
 $row = $result1->fetch_array();
 $sq = "select * from education_details where eid = $id";
 $result2 = $con->query($sq);
 $row2 = $result2->fetch_array();
 

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Professional Resume</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/w3.css">
        <script src="js/bootstrap.min.js"></script>
<style>
       body{
           margin:30px;
           font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
       }     
        </style>
    </head>
    <body>
        <h1 class="text-center w3-text-teal font-weight-bold w3-xxxlarge"><?php echo $row['name']; ?></h1>
        <hr>
        <p class="w3-text-teal"><i class="fa fa-home"></i> <?php echo $row['address']; ?> &nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span><i class="fa fa-envelope"></i> <?php echo $row['email']; ?></span>
        <span class='float-right'><i class="fa fa-phone"></i> <?php echo $row['phone']; ?></span>
        </p>

        <hr>
        <h1 class="w3-teal text-white pl-3 pr-3 pt-2 pb-2"> PROFESSIONAL SUMMARY</h1>
        <p class="mt-5 text-justify">
            <!-- Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. -->
            <?php echo $row2['summary']; ?>
        </p>
        <h1 class="w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2">EMPLOYMENT HISTORY</h1>
        <div class="container-fluid">
            <div class="row pt-5">
                <div class="col-sm-4  border border-left-0 border-top-0 border-bottom-0">
                <b>Starting Date</b> <?php echo $row['sdate']; ?>
                    <br>
                    <br>
                   <b> Ending Date </b> <?php echo $row['edate']; ?>
                </div>
                <div class="col-sm-8">
                    <ul>
                        <li>
                            <b>Wroking as <?php echo $row['job']; ?></b><br>
                              
                                <span class="small"><b>Description : <?php echo $row['desp']; ?></b></span>
                            </li>
                            <br>
                            <br>
                            <!-- <li>
                                <b>Company Name</b><br>
                                    <span class="small">Working as</span><br>
                                    <span class="small"><b>Projects</b> Write</span>
                                </li> -->
                                
                    </ul>
                </div>
            </div>
        </div>
        <h1 class="w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2">EDUCATION</h1>
        <div class="container-fluid">
            <div class="row pt-5">
                <div class="col-sm-4 border border-left-0 border-top-0 border-bottom-0">
                  <b>Graduation Year</b>
                    <br>
                    <br>
                    <?php echo $row2['grad']; ?>
                </div>
                <div class="col-sm-8">
                    <ul>
                        <li>
                            <b class='w3-large'>College Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['college']; ?></span><br>
                                <span class="small"><b>Course: </b> <?php echo $row2['deg']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['gmark']; ?></span><br>
                                <span class="small"><b>City: </b> <?php echo $row2['city']; ?></span><br>
                                <span class="small"><b>State: </b> <?php echo $row2['state']; ?></span>
                                
                                
                            </li>
                            <br>
                            <br>
                        <?php
                            if(($row2['pname']=="NA" || $row2['pdeg']=="NA" || $row2['pdate']=="NA") && ($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA"))
                            {
                             echo "";
                            }
                            else if(($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA"))
                            {
                                ?>
<li>
                            <b class='w3-large'>College or University Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['pname']; ?></span><br>
                                <span class="small"><b>Programme Name: </b> <?php echo $row2['pdeg']; ?></span><br>
                                <span class="small"><b>Year of Studies: </b> <?php echo $row2['pdate']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['pmark']; ?></span><br>
                              
                                
                                
                                
                                </li>
                                <br>
                                <br>    
                           
                                <?php
                            }
                            else{
                               ?>
                                 <li>
                            <b class='w3-large'>College or University Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['pname']; ?></span><br>
                                <span class="small"><b>Programme Name: </b> <?php echo $row2['pdeg']; ?></span><br>
                                <span class="small"><b>Year of Studies: </b> <?php echo $row2['pdate']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['pmark']; ?></span><br>
                              
                                
                                
                                
                                </li>
                                <br>
                                <br>
                                <li>
                            <b class='w3-large'>College or University Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['oname']; ?></span><br>
                                <span class="small"><b>Programme Name: </b> <?php echo $row2['odeg']; ?></span><br>
                                <span class="small"><b>Year of Studies: </b> <?php echo $row2['odate']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['omark']; ?></span><br>
                              
                                
                                
                                
                                </li>
                                <br>
                                <br>
                               <?php
                            }

                            ?>
                            <li>
                            <b class='w3-large'>School Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['school']; ?></span><br>
                                <span class="small"><b>Year of Higher Studies: </b> <?php echo $row2['high']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['marks']; ?></span><br>
                                <span class="small"><b>City: </b> <?php echo $row2['sc']; ?></span><br>
                                <span class="small"><b>State: </b> <?php echo $row2['ss']; ?></span>
                                
                                
                                
                                </li>
                                
                    </ul>
                </div>
            </div>
        </div>
        <h1 class="w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2">SKILLS</h1>
        <div class="container-fluid">
            <div class="row pt-5">
                <div class="col-sm-4 border border-left-0 border-top-0 border-bottom-0">
                <ul>
                <li><b><?php echo $row2['skill']; ?><b></li>
                <br>
                <li><b><?php echo $row2['skill2']; ?><b></li>
                <br>
                <li><b><?php echo $row2['skill3']; ?><b></li>
                </ul>
                </div>
                <div class="col-sm-8">
                    <ul>
                        <li>
                        <b><?php echo $row2['level']; ?><b>
                            </li>
                            <br>
                            <br>
                            <li>
                            <b><?php echo $row2['level2']; ?><b>
                                </li>
                                <br>
                                <br>
                                <li>
                            <b><?php echo $row2['level3']; ?><b>
                                </li>
                                
                                
                    </ul>
                </div>
            </div>
    </div>
            <h1 class="w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2">HOBBIES</h1>
            <div class="container-fluid">
            <div class="row pt-5">
                <div class="col-sm-12 border border-left-0 border-top-0 border-bottom-0">
                <ul>
                <li><b><?php echo $row2['h1']; ?><b></li>
                <br>
                <li><b><?php echo $row2['h2']; ?><b></li>
               
                </ul>
                </div>
    </div>
    </div>
        
        <a href='generatepdf.php?id=<?php echo $id ?>' class='btn btn-danger'>Generate PDF</a>
        <a href='editdetails.php?id=<?php echo $id ?>' class='btn btn-primary float-right'>Edit Details</a>
    </body>
</html>