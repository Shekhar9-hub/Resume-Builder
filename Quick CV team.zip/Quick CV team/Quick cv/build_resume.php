
<?php
session_start();
if(!isset($_SESSION['user']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('usernav.php');

}
include('dbconn.php');
$e = $_SESSION['email'];
$tid = $_GET['id'];
$query = "select * from personal_details where email = '".$_SESSION['email']."'";
    $result = $con->query($query);
    $row = $result->fetch_array();
 $fk = $row['id'];
//  $q = "select * from education_details where eid = $fk";
//  $r = $con->query($q);
//  $rr=$r->fetch_array();
 
  if($row['email'] == $e)
  {
      echo "<script>location.replace('build.php?eid=".$fk."&tmp_id=".$tid."');
      
      </script>";
  }

else{

?>

<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <div class="row" style="padding-top:50px">
  <h1 class="text-center"><b>FILL YOUR DETAILS</h1><br>
    <div class="col-sm-6">
    <h1>Personal Details</h1>
    <form method='post'>
    <div class='form-group'>
    <input type='text' placeholder='Enter your full Name' class='form-control' name="name" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Address' class='form-control'  name="address" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your City' class='form-control' name="city"  required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Zipcode' class='form-control'  name="zip" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Country' class='form-control'  name="country" required>
    </div>
    <div class='form-group'>
    <input type='email' placeholder='Enter your Email' class='form-control' name="email" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Phone No.' class='form-control'  name="phone"  pattern="[0-9]{10}" required>
    </div>
 
     
    </div>
    <div class="col-sm-6">
   
    <h1>Experience Details</h1>
  
    <div class='form-group'>
    <input type='text' placeholder='Enter your Job Title' class='form-control'  name='job' required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your State' class='form-control'  name='state' required>
    </div>
    <div class='form-group'>
    Starting Date
    <input type='month' class='form-control' name='sdate'  required>
    </div>
    <div class='form-group'>
    Ending Date
    <input type='month' class='form-control' name='edate'  required>
    </div>
    <div class='form-group'>
    <textarea class='form-control' placeholder='Write Job Description' name='desp'></textarea>
    </div>


    <br><input type='submit' class="btn btn-primary btn-lg pull-right" name='save1' value='Save and Next'></a>
    </form>

    </div>
  </div>
</div>

<!-- <div id="about" class="container-fluid">
  <div class="row" style="padding-top:50px">
  
    <div class="col-sm-6">
    <h1>Education Section</h1>
   
    <div class='form-group'>
    <input type='text' placeholder='Enter your College or University Name' class='form-control'  name="cname"  required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your City' class='form-control'  name="c" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your State' class='form-control'  name="state" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Degree' class='form-control'  name="deg" required>
    </div>
    <div class='form-group'>
    Graduation Date

    <input type='month' class='form-control'  name="grad" required>
    </div>
    <div class='form-group'>
    <input type='number' placeholder='Enter your Marks in graduation'  name="gmark" class='form-control' required min="20" max="100">
    </div>
    
    <div class='form-group'>
    <input type='text' placeholder='Enter your School'  name="school" class='form-control' required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your City'  name="cs" class='form-control' required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your State' name="ss"  class='form-control' required>
    </div>
    <div class='form-group'>
    <input type='number' placeholder='Enter your Marks in +2'  name="high" class='form-control' required min="20" max="100">
    
    </div>
    <div class='form-group'>
    Higher Secondary
    
    <input type='month' class='form-control' name="sm"  required>
    </div>

 
     
    </div>
    <div class="col-sm-6">
   
    <h1>Skills</h1>
  
    <div class='form-group'>
    <input type='text' placeholder='Enter your Skill' class='form-control' name='s1' required>
    </div>
    <div class='form-group'>
    <select name='skill1' class='form-control' required>
    <option value=''>Please Select</option>
    <option value='Novice'>Novice</option>
    <option value='Beginner'>Beginner</option>
    <option value='Experienced'>Experienced</option>
    
    
    
    </select>
        </div>
        <div class='form-group'>
    <input type='text' placeholder='Enter your Skill' class='form-control' name='s2' required>
    </div>
    <div class='form-group'>
    <select name='skill2' class='form-control' required>
    <option value=''>Please Select</option>
    <option value='Novice'>Novice</option>
    <option value='Beginner'>Beginner</option>
    <option value='Experienced'>Experienced</option>
    
    
    
    </select>
        </div><div class='form-group'>
    <input type='text' placeholder='Enter your Skill' class='form-control' name='s3' required>
    </div>
    <div class='form-group'>
    <select name='skill3' class='form-control' required>
    <option value=''>Please Select</option>
    <option value='Novice'>Novice</option>
    <option value='Beginner'>Beginner</option>
    <option value='Experienced'>Experienced</option>
    
    
    
    </select>
        </div>

        <div class='form-group'>
    <textarea class='form-control' placeholder='Professional Summary' name='summary'></textarea>
    </div>
    
    <br><input type='submit' class="btn btn-primary btn-lg pull-right" name='save1' value='Save and Next'></a>
    </form>
    </div>
  </div> -->
</div>
<?php

//echo "<center><a href='view.php?id=".$id."' class='btn btn-danger'>Go and Download Resume</a></center>";
if(isset($_POST['save1']))
{
    //Personal Details

    $id = $_GET['id'];
  $a=$_POST['name'];
  $b=$_POST['address'];
  $c=$_POST['city'];
  $d=$_POST['zip'];
  $e=$_POST['country'];
  $f=$_POST['email'];
  $g=$_POST['phone'];
  $a1=$_POST['job'];
  $b1=$_POST['state'];
  $c1=$_POST['sdate'];
  $d1=$_POST['edate'];
  $e1=$_POST['desp'];
  include('dbconn.php');
  $query = "select * from personal_details where email = '$f'";
  $result = $con->query($query);
  $row=$result->fetch_array();
  if($row['email'] == $f)
  {
      echo "<script>alert('Email Id already exists');
      
      </script>";
  }
  else
  {
 include('dbconn.php');
 $q = "insert into personal_details(name,address,city,zip,country,email,phone,job,state,sdate,edate,desp,temp_id) 
 values ('$a','$b','$c','$d','$e','$f','$g','$a1','$b1','$c1','$d1','$e1',$id)";
//  $q1 = "insert into education_details(eid,college,city,state,deg,grad,gmark,school,sc,ss,marks,high,skill,level,skill2,level2,skill3,level3,summary,temp_id) 
//  values ('$u','$a2','$b2','$c2','$d2','$e2',$f2,'$g2','$a3','$b3',$c3,'$d3','$e4','$e5','$e6','$e7','$e8','$e9','$e10',$id)";
 
 if($con->query($q))
 {
  echo "<script> location.replace('education.php'); </script>";  
 }
 else{
    echo "<script>alert('Try Again!! Error Occur'); location.replace('build_resume.php');</script>";
 }
 //echo "<center><a href='view.php?id='".$id."' class='btn btn-danger'>Go and Download Resume</a></center>";
}
}
}
?>
 
