<?php 
  
// Enter the name of directory 
$pathdir = "student resume/";  
  
// Enter the name to creating zipped directory 
$zipcreated = "Name of Zip.zip"; 
  
// Create new zip class 
$zip = new ZipArchive; 
$f = array("Professional Resume 4.pdf","Creative Resume 4.pdf");
$zip -> open($zipcreated, ZipArchive::OVERWRITE);
      
    // Store the path into the variable 
    $dir = opendir($pathdir); 
       
    // while($file = readdir($dir)) { 
        foreach($f as $val){
        if(file_exists($pathdir.$val)) { 
            $zip->addFile($pathdir.$val, $val); 
        } 
    } 
    $zip ->close(); 
 
  
?> 