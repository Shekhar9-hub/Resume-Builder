<?php
session_start();
if(!isset($_SESSION['admin']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('adminnav.php');
    ?>
<div class="container-fluid" style='width:50%;padding-top:100px'>
  <div class="row">
    <div class="col-sm-4">
    <!-- <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
     -->
    </div>
    <div class="col-sm-8 text-center">
        <h1 class='text-center'>
            Admin Change Password</h1>
            <br>
            
		<form method="post">
		<input type="password" class="form-control" name="new" placeholder="New Password" required>
			<br>
			<input type="password" class="form-control" name="confirm" placeholder="Confirm Password" required>
			<br>
			<button type="submit" class="w3-button w3-orange w3-text-white" name="login">Submit</button>
			<button type="reset" class="w3-button w3-black w3-text-white">Reset</button>	
		</form>
    
  </div>
  
</div>
</div>
<?php
if(isset($_POST['login']))
{
	$a = $_POST['new'];
	$b = $_POST['confirm'];
	if(!($a == $b))
	{
		echo "<script>alert('Password should be matched');</script>";
	}
	else
	{
		include('dbconn.php');
		$a = "update admin set password='$a' where id=1";
		if($con->query($a))
		{
			echo "<script>alert('Updated');</script>";
		}
		else
		{
			echo "<script>alert('Not Updated');</script>";
		}
		
	}
}
}
?>
