<?php
session_start();
if(!isset($_SESSION['user']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('usernav.php');
}



?>
<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <div class="row" style="padding-top:100px">
    <div class="col-sm-6">
      <h1><b>IMPRESSIVE RESUMES <b><BR> EASY ONLINE BUILDER</h1><br>
      <h4 class='text-justify'>Picking the perfect format for your needs is one of the most important choices you’ll make on your resume. For many recruiters, the wrong format may be a huge pet peeve and get you rejected almost immediately. But don’t worry, below, we break down everything you need to consider to make the right choice.</h4><br>
      <p>

</p>
      <br><a class="btn btn-primary btn-lg" href='#'>BUILD RESUME</a>
    </div>
    <div class="col-sm-6 text-center">
      <img src='img/resume.jpeg' class='img-fluid shadow' style='height:400px;object-fit:cover;'>
    </div>
  </div>
</div>
<div id="portfolio" class="container-fluid text-center bg-grey">
  <h2>3 EASY STEPS TO CREATE YOUR PERFECT RESUME</h2><br>
  <h4>What we created</h4>
  <div class="row text-center">
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/resume.jpeg"  width="400" height="300">
        <p><strong>Choose Your <br> Resume Template</strong></p>
        <p>Our professional resume templates are designed strictly following all industry guidelines and best practices</br> employers are looking for.</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/r.jpeg"  width="400" height="300">
        <p><strong>Show what <br />you´re made of</strong></p>
        <p>Not finding the right words to showcase yourself? We´ve added thousands of pre-written examples and resume samples.  </br>As easy as a click.</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/resume.jpeg" width="400" height="300">
        <p><strong>Download <br /> Your resume</strong></p>
        <p>Start impressing employers. Download your awesome resume and land the job you are looking for, effortlessly.</p>
      </div>
    </div>
  </div><br>

  <div id="portfolio" class="container-fluid text-center bg-grey">
  <h2  id="resume">PROFESSIONAL RESUME TEMPLATES</h2><br>
  <h4>What we created</h4>
  <div class="row text-center">
    <div class="col-sm-4">
      <div class="thumbnail">
        <a href='build_resume.php?id=3'><img src="img/Picture1.png" style='height:500px; border-bottom:2px solid teal;width:100%;object-fit:cover'></a>
        <p><strong>Simple Template</strong></p>
        <p>Choose Template</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
      <a href='build_resume.php?id=1'><img src="img/Picture2.png" style='height:500px; border-bottom:2px solid teal;width:100%;object-fit:cover'></a>
        <p><strong>Professional Template</strong></p>
      <p>Choose Template</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
      <a href='build_resume.php?id=2'><img src="img/Picture4.png" style='height:500px; border-bottom:2px solid teal;width:100%;object-fit:cover'></a>
                <p><strong>Creative Template</strong></p>
      <p>Choose Template</p>
      </div>
    </div>
  </div><br>
<a class='btn btn-primary btn-lg' href='#'>BUILD RESUME</a>
  
  <footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p> Developed by Us</p>
</footer>
