<?php
session_start();
if(!isset($_SESSION['admin']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('adminnav.php');
    ?>
<div class="container-fluid bg-grey">
  <div class="row">
    <div class="col-sm-4">
    <!-- <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
     -->
    </div>
    <div class="col-sm-8 text-center">
          <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
    
  </div>
  
</div>

<div class="row">
    <div class="col-sm-4">
    <!-- <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
     -->
    </div>
    <div class="col-sm-8">
      <h2>Our Values</h2><br>
      <h4><strong>MISSION:</strong> Our institution teach students how to come up with winning professional resumes and overlook the importance of student- and entry-level resumes. Yet, the latter are important in ensuring the student enters the job market to gain relevant experience that will then feature in the professional resume.

This becomes a problem for students intending to create a resume. </h4><br>
      <p><strong>VISION:</strong> Given this challenge, it is important for any resume templates intended for students to highlight the section about education more prominently. Emphasizing on awards/honors, GPA scores and exemplary performances in extracurricular activities is important. As is the case with entry-level resumes, including volunteer work experience and internships is also a good idea for student resumes.</p></div>
  </div>
</div>

<?php
}
?>