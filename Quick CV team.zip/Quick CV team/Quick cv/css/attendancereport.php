<?php
include('edashboard.php');

echo "<div class='container-fluid m-5' style='padding:10px 250px'>";
include("oconn.php");
$employee = $_SESSION['employee'];
$sq = "select * from ATTENDANCE where USERNAME = '$employee'";
$stid = oci_parse($conn,$sq);
oci_execute($stid);

echo "<caption>Daily Attendance</caption><table  class='table table-hover table-primary table-bordered'>";
$cnt = 1;
echo "<tr><th>Sr. No.</th><th>Name</th><th>Date</th><th>Starting Time</th></tr>";
while ($row = oci_fetch_array($stid, OCI_BOTH)) {
    echo "<tr><td>$cnt</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td></tr>";
    $cnt++;
}
echo "</table>";

?>