
<!DOCTYPE html>
<html lang="en">
<head>
 
  <title>Online Resume Buider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV Admin Dashboard</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
       
        <li><a href="welcomeadmin.php">SEE RESUME</a></li>
        
        <li><a href="welcomeadmin.php" style='text-transform:uppercase'>Hello Admin</a></li>
        <li><a href="adminlogout.php">LOGOUT</a></li>
        
      </ul>
    </div>
  </div>
</nav>
<br>
<br>
<div class="container-fluid pt-5 mt-5" style="width:70%">
<form method="post">
<input type="search" name="show" class="form-control" placeholder="Search By Programme Name">
<br>
<input type="submit" name="search" value="Show" class="btn btn-warning pull-right">
</form>
</div>
<?php
if(isset($_POST['search']))
{
$search = $_POST['show'];
include('dbconn.php');
$sql = "SELECT * FROM student_resume
WHERE course LIKE '%".$search."%'";
$r = $con->query($sql);
$cnt = 1;
echo "<div class='container-fluid pt-5 mt-5' style='width:70%'>
<table class='table'>
<tr><th>Sr. No.</th><th>Name</th><th>Course</th><th>Resume</th></tr>
<form method='post'>";
while($row = $r->fetch_array())
{
    echo "<tr></tr><td>$cnt</td><td>".$row['name']."</td><td>".$row['course']."</td>";
    echo "<td><input type='checkbox' value='".$row['resume']."' name='items[]'>Download</td></tr>";
$cnt++;
}
echo "<td colspan='4'><input type='submit' value='Download' name='download' class='btn btn-primary pull-right'></td>";
echo "</form></table></div>";
}
// if(isset($_POST['download']))
// {
//     // Enter the name of directory 
// $pathdir = "student resume/";
//     // $f = $_POST['RB'];
//     // $f = array("Professional Resume.pdf","Creative Resume.pdf");
//     // $a = "resume.zip";
//     // $zip = new ZipArchive();
//     // $zip->open($a,ZIPARCHIVE::OVERWRITE);
//     foreach($_POST['RB'] as $val)
//     {
//         // $zip->addFile("student resume/".$val,$val);
//         echo "student resume".$val,$val;
//     }
//     // $zip->close();
//     // // header('Content-Type: application/zip');
//     // // header('Content-disposition: attachment; filename='.$a);
//     // // header('Content-Length: ' . filesize($a)."\\n");
//     // // readfile($a);

// }
if(isset($_POST['download']))
{
if(isset($_POST['items'])) {
    // open zip
    $zip_path = 'download.zip';
    $zip = new ZipArchive();
  
    if ($zip->open($zip_path, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE) !== TRUE) {
      die ("An error occurred creating your ZIP file.");
    }
  
    foreach ($_POST['items'] as $path) {
  
      // generate filename to add to zip
      $filepath = 'student resume/' . $path;
  
      if (file_exists($filepath)) {
        $zip->addFile($filepath, $path) or die ("ERROR: Could not add the file $filename");
      } else {
        die("File $filepath doesnt exit");
      }
    }
    
    $zip->close();
   
    $file='download.zip';
    if (headers_sent()) {
        echo 'HTTP header already sent';
    } else {
        if (!is_file($file)) {
            header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found');
            echo 'File not found';
        } else if (!is_readable($file)) {
            header($_SERVER['SERVER_PROTOCOL'].' 403 Forbidden');
            echo 'File not readable';
        } else {
            while (ob_get_level()) {
                ob_end_clean();
            }
           ob_start();
           header($_SERVER['SERVER_PROTOCOL'].' 200 OK');
           header("Content-Type: application/zip");
           header("Content-Transfer-Encoding: Binary");
           header("Content-Length: ".filesize($file));
           header('Pragma: no-cache');
           header("Content-Disposition: attachment; filename=\"".basename($file)."\"");
           ob_flush();
           ob_clean();
           readfile($file);
           exit;
       }
    }
 
        // header('Content-Type: application/zip');
        // header('Content-disposition: attachment; filename='.$zip_path);
        // // header('Content-Length: ' . filesize($zip_path));
        // // readfile($zip_path);
  }

}


?>