<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Resume Buider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60" class="bg-grey">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">ABOUT</a></li>
        <li><a href="services.php">SERVICES</a></li>
        <li><a href="signin.php">CREATE RESUME</a></li>
        <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>
<!-- Container (Services Section) -->
<div id="services" class="container-fluid text-center">
  <h2 style="padding-top:100px">SERVICES</h2>
  <h4 style="padding-bottom:50px">What we offer</h4>
  <br>
  <div class="row">
    <div class="col-sm-4">
     <img src="img/image_2.jpg" style='width:100%'>
      <h4>Education Section</h4>
      <p>This is the most vital component of the student-level resume. In fact, its significance takes after that of the work experience section in the professional resume. Potential employers are likely to review the section on education first before reading other sections in the student-level resume. Therefore, including the most relevant information in the education section is paramount.</p>
    </div>
    <div class="col-sm-4">
    <img src="img/image_3.jpg" style='width:100%'>
      <h4>Accomplishments</h4>
      <p>This section in the student-level resume is equivalent to the work experience section in the professional resume. Its relevance is to cover for the lack of work experience. In this section, the student should clearly and make known all their extracurricular and academic accomplishments in detail when creating his/her resume. Examples of details might include leadership opportunities, outstanding GPAs, honorary, and academic contest awards.</p>
    </div>
    <div class="col-sm-4">
    <img src="img/image_4.jpg" style='width:100%'>
      <h4>References</h4>
      <p>
      Despite the recommendation not to include the contacts to references in the resume, 
      students especially those in lower education levels such as high school should have a ready
       list of potential or even confirmed references. Such references might include teachers, 
       community leaders, church/temple/mosque leaders, and coaches. It is critical that the 
       student is known to the references. The references should also be conversant with 
        of the achievements of the student as to be able to vouch for their suitability. 
      </p>
    </div>
  </div>
  <br><br>
  <div class="row">
    <div class="col-sm-4">
    <img src="img/image_4.jpg" style='width:100%'>
      <h4>References</h4>
      <p>
      Despite the recommendation not to include the contacts to references in the resume, 
      students especially those in lower education levels such as high school should have a ready
       list of potential or even confirmed references. Such references might include teachers, 
       community leaders, church/temple/mosque leaders, and coaches. It is critical that the 
       student is known to the references. The references should also be conversant with 
        of the achievements of the student as to be able to vouch for their suitability. 
      </p>
    </div>
    <div class="col-sm-4">
    <img src="img/image_2.jpg" style='width:100%'>
      <h4>Education Section</h4>
      <p>This is the most vital component of the student-level resume. In fact, its significance takes after that of the work experience section in the professional resume. Potential employers are likely to review the section on education first before reading other sections in the student-level resume. Therefore, including the most relevant information in the education section is paramount.</p>

    </div>
    <div class="col-sm-4">
    <img src="img/image_3.jpg" style='width:100%'>
      <h4>Accomplishments</h4>
      <p>This section in the student-level resume is equivalent to the work experience section in the professional resume. Its relevance is to cover for the lack of work experience. In this section, the student should clearly and make known all their extracurricular and academic accomplishments in detail when creating his/her resume. Examples of details might include leadership opportunities, outstanding GPAs, honorary, and academic contest awards.</p>
    
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p> Developed by Us</p>
</footer>

</body>
