
<?php
session_start();
$id = $_GET['id'];
include('dbconn.php');
$sql = "select * from personal_details where id = $id";
$result1 = $con->query($sql);
$row = $result1->fetch_array();
$sq = "select * from education_details where eid = $id";
$result2 = $con->query($sq);
$row2 = $result2->fetch_array();  
$name = $row['name'];
$course = $row2['deg'];
$resume = "Professional Resume ".$id.".pdf";
$q = "insert into student_resume(sid,name,course,resume) values($id,'$name','$course','$resume')";
$con->query($q);  
if(($row2['pname']=="NA" || $row2['pdeg']=="NA" || $row2['pdate']=="NA") && ($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA")){
$html = "<!DOCTYPE html>
<html>
<head>
<title>Professional Resume</title>
<style>

  body{
    font-family:sans-serif;
  }
  h1{
padding:0px;
font-weight:light;
margin:0px;
  }
.text-center{
    text-align:center;
    font-size:50px;
}
.w3-text-teal{
    color:teal;
}
.w3-teal{
    background-color:teal;
    color:white;
    padding:10px;
    margin-top:20px;
  
}
.container-fluid{
margin-top:20px;
}
.row{
margin-bottom:50px;
}
.col-sm-4{
    width:25%;
    height:auto;
    float:left;
}

.col-sm-8{
    width:72%;
    height:auto;
   float:left;
}

</style>
</head>
<body>

<h1 class='text-center w3-text-teal'>". $row['name']."</h1>

<hr><p class='w3-text-teal'>".$row['address']."&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           
        <span>".$row['email']."</span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span  align='right'>".$row['phone']."</span>
        </p><hr>
        <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2'> PROFESSIONAL SUMMARY</h1>
        <p class='mt-5 text-justify'>
           ".$row2['summary']."
        </p>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white h1'> EMPLOYEMENT HISTORY</h1>
        
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4'>
                <b>Starting Date</b>". $row['sdate']."</b>
                    <br>
                    <br>
                   <b> Ending Date </b>". $row['edate']."</b>
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                            <b>Working as ".$row['job']."</b><br>
                              
                                <span class='small'><b>Description : ".$row['desp']."</b></span>
                            </li>
                            <br>
                            <br>
                          
                                
                    </ul>
                </div>
            </div>

        </div>
        <br>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white  pl-3 pr-3 pt-2 pb-2'>EDUCATION</h1>
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4 border border-left-0 border-top-0 border-bottom-0'>
                  <b>Graduation Year</b>
                    <br>
                    <br>"
                .$row2['grad']."
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                            <b class='w3-large'>College Name</b><br>
                                <span class='font-weight-bold>".$row2['college']."</span><br>
                                <span class='small'><b>Course: </b>".$row2['deg']."</span><br>
                                <span class='small'><b>Marks: </b>". $row2['gmark']." </span><br>
                                <span class='small'><b>Marks: </b>".$row2['city']." </span><br>
                                <span class='small'><b>Marks: </b>". $row2['state']."</span>
                                
                                
                            </li>
                            <br>
                            <br>
                            <li>
                            <b class='w3-large'>School Name</b><br>
                                <span class='font-weight-bold'>".$row2['school']."</span><br>
                                <span class='small'><b>Year of Higher Studies: </b>".$row2['high']."</span><br>
                                <span class='small'><b>Marks: </b>".$row2['marks']."</span><br>
                                <span class='small'><b>Marks: </b>".$row2['sc']."</span><br>
                                <span class='small'><b>Marks: </b>".$row2['ss']."</span>
                                
                                
                                
                                </li>
                                
                    </ul>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br> <br>
        <br>  <br>
        <br> 
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2'>HOBBIES</h1>
        <div class='container-fluid'>
        <div class='row pt-5'>
        <div class='col-sm-12'>
        <ul>
        <li><b>".$row2['h1']."<b></li>
        <li><b>".$row2['h2']."<b></li>
        </ul>
        </div>
        </div>
        </div>
     <h1 class='w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2'>SKILLS</h1>
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4 border border-left-0 border-top-0 border-bottom-0'>
                <ul>
                <li><b>".$row2['skill']."<b></li>
                <br>
                <li><b>".$row2['skill2']."<b></li>
                <br>
                <li><b>".$row2['skill3']."</b></li>
                </ul>
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                        <b>".$row2['level']."<b>
                            </li>
                            <br>
                            <br>
                            <li>
                            <b>".$row2['level2']."<b>
                                </li>
                                <br>
                                <br>
                                <li>
                            <b>".$row2['level3']."<b>
                                </li>
                                
                                
                    </ul>
                </div>
            </div>
        </div>
</body>
</html>";
}
else if(($row2['oname']=="NA" || 
$row2['odeg']=="NA" || $row2['odate']=="NA"))
{
    $html = "<!DOCTYPE html>
<html>
<head>
<title>Professional Resume</title>
<style>

  body{
    font-family:sans-serif;
  }
  h1{
padding:0px;
font-weight:light;
margin:0px;
  }
.text-center{
    text-align:center;
    font-size:50px;
}
.w3-text-teal{
    color:teal;
}
.w3-teal{
    background-color:teal;
    color:white;
    padding:10px;
    margin-top:20px;
  
}
.container-fluid{
margin-top:20px;
}
.row{
margin-bottom:50px;
}
.col-sm-4{
    width:25%;
    height:auto;
    float:left;
}

.col-sm-8{
    width:72%;
    height:auto;
   float:left;
}

</style>
</head>
<body>

<h1 class='text-center w3-text-teal'>". $row['name']."</h1>

<hr><p class='w3-text-teal'>".$row['address']."&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           
        <span>".$row['email']."</span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span  align='right'>".$row['phone']."</span>
        </p><hr>
        <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2'> PROFESSIONAL SUMMARY</h1>
        <p class='mt-5 text-justify'>
           ".$row2['summary']."
        </p>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white h1'> EMPLOYEMENT HISTORY</h1>
        
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4'>
                <b>Starting Date</b>". $row['sdate']."</b>
                    <br>
                    <br>
                   <b> Ending Date </b>". $row['edate']."</b>
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                            <b>Working as ".$row['job']."</b><br>
                              
                                <span class='small'><b>Description : ".$row['desp']."</b></span>
                            </li>
                            <br>
                            <br>
                          
                                
                    </ul>
                </div>
            </div>

        </div>
        <br>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white  pl-3 pr-3 pt-2 pb-2'>EDUCATION</h1>
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4 border border-left-0 border-top-0 border-bottom-0'>
                
                  <b>Graduation Year</b>
                    <br>
                    <br>"
                .$row2['grad']."
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                            <b class='w3-large'>College Name</b><br>
                                <span class='font-weight-bold>".$row2['college']."</span><br>
                                <span class='small'><b>Course: </b>".$row2['deg']."</span><br>
                                <span class='small'><b>Marks: </b>". $row2['gmark']." </span><br>
                                <span class='small'><b>City: </b>".$row2['city']." </span><br>
                                <span class='small'><b>State: </b>". $row2['state']."</span>
                        </li>
                         
                        <li>
                            <b class='w3-large'>Post Graduation </b><br>
                                <span class='font-weight-bold>".$row2['pname']."</span><br>
                                <span class='small'><b>Course: </b>".$row2['pdeg']."</span><br>
                                <span class='small'><b>Year: </b>". $row2['pdate']." </span><br>
                                <span class='small'><b>Marks: </b>".$row2['pmark']." </span><br>
                               
                                
                                
                        </li>
                            <br>
                            <br>
                        <li>
                            <b class='w3-large'>School Name</b><br>
                                <span class='font-weight-bold'>".$row2['school']."</span><br>
                                <span class='small'><b>Year of Higher Studies: </b>".$row2['high']."</span><br>
                                <span class='small'><b>Marks: </b>".$row2['marks']."</span><br>
                                <span class='small'><b>City: </b>".$row2['sc']."</span><br>
                                <span class='small'><b>State: </b>".$row2['ss']."</span>
                        </li>
                             
                                
                                
                    </ul>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br> <br>
        <br>  <br>
        <br> 
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2'>HOBBIES</h1>
        <div class='container-fluid'>
        <div class='row pt-5'>
        <div class='col-sm-12'>
        <ul>
        <li><b>".$row2['h1']."<b></li>
        <li><b>".$row2['h2']."<b></li>
        </ul>
        </div>
        </div>
        </div>
     <h1 class='w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2'>SKILLS</h1>
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4 border border-left-0 border-top-0 border-bottom-0'>
                <ul>
                <li><b>".$row2['skill']."<b></li>
                <br>
                <li><b>".$row2['skill2']."<b></li>
                <br>
                <li><b>".$row2['skill3']."</b></li>
                </ul>
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                        <b>".$row2['level']."<b>
                            </li>
                            <br>
                            <br>
                            <li>
            
                            <b>".$row2['level2']."<b>
                                </li>
                                <br>
                                <br>
                                <li>
                            <b>".$row2['level3']."<b>
                                </li>
                                
                                
                    </ul>
                </div>
            </div>
        </div>
        
</body>
</html>";
}
else
{
    $html = "<!DOCTYPE html>
<html>
<head>
<title>Professional Resume</title>
<style>

  body{
    font-family:sans-serif;
  }
  h1{
padding:0px;
font-weight:light;
margin:0px;
  }
.text-center{
    text-align:center;
    font-size:50px;
}
.w3-text-teal{
    color:teal;
}
.w3-teal{
    background-color:teal;
    color:white;
    padding:10px;
    margin-top:20px;
  
}
.container-fluid{
margin-top:20px;
}
.row{
margin-bottom:50px;
}
.col-sm-4{
    width:25%;
    height:auto;
    float:left;
}

.col-sm-8{
    width:72%;
    height:auto;
   float:left;
}

</style>
</head>
<body>

<h1 class='text-center w3-text-teal'>". $row['name']."</h1>

<hr><p class='w3-text-teal'>".$row['address']."&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           
        <span>".$row['email']."</span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span  align='right'>".$row['phone']."</span>
        </p><hr>
        <h1 class='w3-teal text-white pl-3 pr-3 pt-2 pb-2'> PROFESSIONAL SUMMARY</h1>
        <p class='mt-5 text-justify'>
           ".$row2['summary']."
        </p>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white h1'> EMPLOYEMENT HISTORY</h1>
        
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4'>
                <b>Starting Date</b>". $row['sdate']."</b>
                    <br>
                    <br>
                   <b> Ending Date </b>". $row['edate']."</b>
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                            <b>Working as ".$row['job']."</b><br>
                              
                                <span class='small'><b>Description : ".$row['desp']."</b></span>
                            </li>
                            <br>
                            <br>
                          
                                
                    </ul>
                </div>
            </div>

        </div>
        <br>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white  pl-3 pr-3 pt-2 pb-2'>EDUCATION</h1>
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4 border border-left-0 border-top-0 border-bottom-0'>
                
                  <b>Graduation Year</b>
                    <br>
                    <br>"
                .$row2['grad']."
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                            <b class='w3-large'>College Name</b><br>
                                <span class='font-weight-bold>".$row2['college']."</span><br>
                                <span class='small'><b>Course: </b>".$row2['deg']."</span><br>
                                <span class='small'><b>Marks: </b>". $row2['gmark']." </span><br>
                                <span class='small'><b>City: </b>".$row2['city']." </span><br>
                                <span class='small'><b>State: </b>". $row2['state']."</span>
                        </li>
                         
                        <li>
                            <b class='w3-large'>Post Graduation </b><br>
                                <span class='font-weight-bold>".$row2['pname']."</span><br>
                                <span class='small'><b>Course: </b>".$row2['pdeg']."</span><br>
                                <span class='small'><b>Year: </b>". $row2['pdate']." </span><br>
                                <span class='small'><b>Marks: </b>".$row2['pmark']." </span><br>
                               
                                
                                
                        </li>
                        <li>
                            <b class='w3-large'>Other Education or Diploma </b><br>
                                <span class='font-weight-bold>".$row2['oname']."</span><br>
                                <span class='small'><b>Course: </b>".$row2['odeg']."</span><br>
                                <span class='small'><b>Year: </b>". $row2['odate']." </span><br>
                                <span class='small'><b>Marks: </b>".$row2['omark']." </span><br>
                               
                                
                                
                        </li>
                        
                            <br>
                            <br>

                        <li>
                            <b class='w3-large'>School Name</b><br>
                                <span class='font-weight-bold'>".$row2['school']."</span><br>
                                <span class='small'><b>Year of Higher Studies: </b>".$row2['high']."</span><br>
                                <span class='small'><b>Marks: </b>".$row2['marks']."</span><br>
                                <span class='small'><b>City: </b>".$row2['sc']."</span><br>
                                <span class='small'><b>State: </b>".$row2['ss']."</span>
                        </li>
                             
                                
                                
                    </ul>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br> <br>
        <br>  <br>
        <br> 
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h1 class='w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2'>HOBBIES</h1>
        <div class='container-fluid'>
        <div class='row pt-5'>
        <div class='col-sm-12'>
        <ul>
        <li><b>".$row2['h1']."<b></li>
        <li><b>".$row2['h2']."<b></li>
        </ul>
        </div>
        </div>
        </div>
     <h1 class='w3-teal text-white mt-5 pl-3 pr-3 pt-2 pb-2'>SKILLS</h1>
        <div class='container-fluid'>
            <div class='row pt-5'>
                <div class='col-sm-4 border border-left-0 border-top-0 border-bottom-0'>
                <ul>
                <li><b>".$row2['skill']."<b></li>
                <br>
                <li><b>".$row2['skill2']."<b></li>
                <br>
                <li><b>".$row2['skill3']."</b></li>
                </ul>
                </div>
                <div class='col-sm-8'>
                    <ul>
                        <li>
                        <b>".$row2['level']."<b>
                            </li>
                            <br>
                            <br>
                            <li>
            
                            <b>".$row2['level2']."<b>
                                </li>
                                <br>
                                <br>
                                <li>
                            <b>".$row2['level3']."<b>
                                </li>
                                
                                
                    </ul>
                </div>
            </div>
        </div>
        
</body>
</html>";
}
?>
<?php

// Include autoloader 
require_once 'dompdf/autoload.inc.php'; 
 
// Reference the Dompdf namespace 
use Dompdf\Dompdf; 
 
// Instantiate and use the dompdf class 
$dompdf = new Dompdf();


$dompdf->loadHtml($html);

 
// (Optional) Setup the paper size and orientation 
$dompdf->setPaper('A4', 'Portrait'); 
 
// Render the HTML as PDF 
$dompdf->render(); 
//$dompdf->set_base_path('../css/bootstrap.min.css');

// Output the generated PDF (1 = download and 0 = preview) 
if(isset($_SESSION['admin']))
{
$dompdf->stream("Professional Resume", array("Attachment" => 1));
 //save the file to the server
    // $output = $dompdf->output();
    // file_put_contents("img/Professional Resume".$id.".pdf", $output);
}
else
{

    $dompdf->stream("Professional Resume", array("Attachment" => 0));
    $output = $dompdf->output();
    file_put_contents("student resume/Professional Resume ".$id.".pdf", $output);
}
?>
